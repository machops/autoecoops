import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({ message: 'Knowledge base API coming soon' }, { status: 501 });
}

export async function POST() {
  return NextResponse.json({ message: 'Knowledge base creation coming soon' }, { status: 501 });
}
