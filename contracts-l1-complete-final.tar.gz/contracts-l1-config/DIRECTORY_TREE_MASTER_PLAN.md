# Contracts-L1 完整目錄樹總圖表與規範

## 📊 目錄樹圖例說明

```
✅ 已完成 - 配置完整,可立即使用
🚧 開發中 - 框架就緒,需實作業務邏輯
⚙️  工作機構 - 運行時必須存在的動態文件
🔒 強制機構 - 必須嚴格遵守規範的關鍵文件
📝 待開發 - 尚未創建的文件
🔧 可選機構 - 根據需求選擇性創建
```

## 🌳 完整目錄樹結構

```
contracts-l1/                                    # 專案根目錄
│
├─── 📋 專案基礎文件 (✅ 已完成)
│    ├── package.json                           # 🔒 根套件配置 | 責任: 依賴管理、腳本定義
│    ├── pnpm-workspace.yaml                    # 🔒 工作區配置 | 責任: Monorepo 套件管理
│    ├── turbo.json                             # 🔒 構建配置 | 責任: 任務編排、快取策略
│    ├── tsconfig.json                          # 🔒 TS根配置 | 責任: 全域型別規則
│    ├── .env.example                           # ✅ 環境範例 | 責任: 環境變數文檔
│    ├── .env.local                             # ⚙️  本地環境 | 責任: 開發環境配置 (不提交)
│    ├── .env.production                        # ⚙️  生產環境 | 責任: 生產配置 (不提交)
│    ├── .gitignore                             # 🔒 Git規則 | 責任: 版本控制過濾
│    ├── .prettierrc                            # 🔒 格式化規則 | 責任: 代碼風格統一
│    ├── .prettierignore                        # 📝 格式化忽略 | 責任: 排除特定文件
│    ├── .eslintrc.js                           # 🔒 檢查規則 | 責任: 代碼品質保證
│    ├── .eslintignore                          # 📝 檢查忽略 | 責任: 排除特定文件
│    ├── LICENSE                                # ✅ 授權文件 | 責任: 法律聲明
│    ├── README.md                              # ✅ 專案說明 | 責任: 整體介紹
│    ├── QUICKSTART.md                          # ✅ 快速開始 | 責任: 5分鐘上手指南
│    ├── CHANGELOG.md                           # 📝 變更日誌 | 責任: 版本歷史記錄
│    ├── CONTRIBUTING.md                        # 📝 貢獻指南 | 責任: 協作規範
│    └── CODE_OF_CONDUCT.md                     # 📝 行為準則 | 責任: 社群規範
│
├─── 🎨 前端應用 (apps/web/) - 🚧 開發中
│    │
│    ├── 📦 套件配置
│    │   ├── package.json                       # 🔒 前端依賴 | 責任: Next.js相關套件
│    │   ├── next.config.js                     # 🔒 Next配置 | 責任: 構建、路由、優化
│    │   ├── tailwind.config.js                 # 🔒 樣式配置 | 責任: 設計系統定義
│    │   ├── postcss.config.js                  # ✅ CSS處理 | 責任: 樣式編譯
│    │   ├── tsconfig.json                      # 🔒 前端TS | 責任: 型別檢查規則
│    │   └── next-env.d.ts                      # ⚙️  Next型別 | 責任: 自動生成型別
│    │
│    ├── 📁 src/ - 源代碼目錄
│    │   │
│    │   ├── 🎯 app/ - Next.js App Router (🚧 開發中)
│    │   │   ├── layout.tsx                     # ✅ 根佈局 | 責任: 全域HTML結構、字體
│    │   │   ├── page.tsx                       # ✅ 首頁 | 責任: 產品介紹、導航入口
│    │   │   ├── globals.css                    # ✅ 全域樣式 | 責任: Tailwind導入、基礎樣式
│    │   │   ├── loading.tsx                    # 📝 載入狀態 | 責任: Suspense回退UI
│    │   │   ├── error.tsx                      # 📝 錯誤邊界 | 責任: 錯誤處理UI
│    │   │   ├── not-found.tsx                  # 📝 404頁面 | 責任: 路由不存在處理
│    │   │   │
│    │   │   ├── 🔐 auth/ - 認證相關頁面 (📝 待開發)
│    │   │   │   ├── login/
│    │   │   │   │   └── page.tsx               # 📝 登入頁 | 責任: 使用者登入表單
│    │   │   │   ├── register/
│    │   │   │   │   └── page.tsx               # 📝 註冊頁 | 責任: 新使用者註冊
│    │   │   │   ├── forgot-password/
│    │   │   │   │   └── page.tsx               # 📝 忘記密碼 | 責任: 密碼重設流程
│    │   │   │   └── verify-email/
│    │   │   │       └── page.tsx               # 📝 驗證信箱 | 責任: 信箱驗證流程
│    │   │   │
│    │   │   ├── 📄 dashboard/ - 主控台 (📝 待開發)
│    │   │   │   ├── layout.tsx                 # 📝 儀表板佈局 | 責任: 側邊欄、頂欄
│    │   │   │   ├── page.tsx                   # 📝 儀表板首頁 | 責任: 統計概覽
│    │   │   │   ├── loading.tsx                # 📝 載入狀態 | 責任: 骨架屏
│    │   │   │   │
│    │   │   │   ├── contracts/ - 契約管理
│    │   │   │   │   ├── page.tsx               # 📝 契約列表 | 責任: 分頁、篩選、排序
│    │   │   │   │   ├── upload/
│    │   │   │   │   │   └── page.tsx           # 📝 上傳頁面 | 責任: 拖放上傳、預覽
│    │   │   │   │   └── [id]/
│    │   │   │   │       ├── page.tsx           # 📝 契約詳情 | 責任: 完整資訊展示
│    │   │   │   │       └── analysis/
│    │   │   │   │           └── page.tsx       # 📝 分析結果 | 責任: AI分析報告
│    │   │   │   │
│    │   │   │   ├── search/ - 語義搜尋
│    │   │   │   │   └── page.tsx               # 📝 搜尋頁面 | 責任: 語義查詢、結果展示
│    │   │   │   │
│    │   │   │   ├── analytics/ - 數據分析
│    │   │   │   │   └── page.tsx               # 📝 分析頁面 | 責任: 圖表、報表
│    │   │   │   │
│    │   │   │   └── settings/ - 設定
│    │   │   │       ├── page.tsx               # 📝 設定首頁 | 責任: 導航菜單
│    │   │   │       ├── profile/
│    │   │   │       │   └── page.tsx           # 📝 個人資料 | 責任: 使用者資訊編輯
│    │   │   │       ├── subscription/
│    │   │   │       │   └── page.tsx           # 📝 訂閱管理 | 責任: 方案升級、配額
│    │   │   │       └── api-keys/
│    │   │   │           └── page.tsx           # 📝 API金鑰 | 責任: 金鑰管理
│    │   │   │
│    │   │   └── 🔧 api/ - API路由 (📝 待開發)
│    │   │       ├── health/
│    │   │       │   └── route.ts               # 📝 健康檢查 | 責任: 前端健康狀態
│    │   │       └── webhooks/
│    │   │           └── route.ts               # 📝 Webhook接收 | 責任: 第三方回調
│    │   │
│    │   ├── 🧩 components/ - React組件 (📝 待開發)
│    │   │   │
│    │   │   ├── 🎨 ui/ - 基礎UI組件
│    │   │   │   ├── button.tsx                 # 📝 按鈕 | 責任: 按鈕變體、狀態
│    │   │   │   ├── input.tsx                  # 📝 輸入框 | 責任: 表單輸入、驗證UI
│    │   │   │   ├── card.tsx                   # 📝 卡片 | 責任: 內容容器
│    │   │   │   ├── dialog.tsx                 # 📝 對話框 | 責任: 模態框、確認
│    │   │   │   ├── dropdown.tsx               # 📝 下拉選單 | 責任: 選項選擇
│    │   │   │   ├── toast.tsx                  # 📝 通知提示 | 責任: 即時消息
│    │   │   │   ├── table.tsx                  # 📝 表格 | 責任: 數據展示
│    │   │   │   ├── tabs.tsx                   # 📝 分頁標籤 | 責任: 內容切換
│    │   │   │   ├── badge.tsx                  # 📝 徽章 | 責任: 狀態標記
│    │   │   │   └── spinner.tsx                # 📝 載入器 | 責任: 載入動畫
│    │   │   │
│    │   │   ├── 📄 contracts/ - 契約相關組件
│    │   │   │   ├── contract-list.tsx          # 📝 契約列表 | 責任: 列表渲染、分頁
│    │   │   │   ├── contract-card.tsx          # 📝 契約卡片 | 責任: 單個契約展示
│    │   │   │   ├── upload-zone.tsx            # 📝 上傳區 | 責任: 拖放、進度條
│    │   │   │   ├── analysis-result.tsx        # 📝 分析結果 | 責任: 報告渲染
│    │   │   │   └── risk-badge.tsx             # 📝 風險標籤 | 責任: 風險等級顯示
│    │   │   │
│    │   │   ├── 🔍 search/ - 搜尋相關組件
│    │   │   │   ├── search-bar.tsx             # 📝 搜尋欄 | 責任: 輸入、建議
│    │   │   │   ├── search-results.tsx         # 📝 搜尋結果 | 責任: 結果列表
│    │   │   │   └── semantic-filters.tsx       # 📝 語義篩選 | 責任: 進階篩選器
│    │   │   │
│    │   │   ├── 📊 analytics/ - 分析圖表組件
│    │   │   │   ├── usage-chart.tsx            # 📝 使用量圖表 | 責任: 趨勢可視化
│    │   │   │   ├── risk-distribution.tsx      # 📝 風險分布 | 責任: 風險統計圖
│    │   │   │   └── stats-card.tsx             # 📝 統計卡片 | 責任: KPI展示
│    │   │   │
│    │   │   └── 🎛️ layout/ - 佈局組件
│    │   │       ├── header.tsx                 # 📝 頂欄 | 責任: 導航、使用者選單
│    │   │       ├── sidebar.tsx                # 📝 側邊欄 | 責任: 主導航
│    │   │       ├── footer.tsx                 # 📝 底欄 | 責任: 連結、版權
│    │   │       └── breadcrumb.tsx             # 📝 麵包屑 | 責任: 路徑導航
│    │   │
│    │   ├── 🎣 hooks/ - 自定義Hooks (📝 待開發)
│    │   │   ├── use-auth.ts                    # 📝 認證Hook | 責任: 登入狀態、令牌
│    │   │   ├── use-contracts.ts               # 📝 契約Hook | 責任: 契約CRUD、列表
│    │   │   ├── use-upload.ts                  # 📝 上傳Hook | 責任: 檔案上傳邏輯
│    │   │   ├── use-search.ts                  # 📝 搜尋Hook | 責任: 語義搜尋邏輯
│    │   │   ├── use-toast.ts                   # 📝 通知Hook | 責任: 通知管理
│    │   │   └── use-media-query.ts             # 📝 媒體查詢 | 責任: 響應式判斷
│    │   │
│    │   ├── 📚 lib/ - 工具函數庫 (📝 待開發)
│    │   │   ├── api.ts                         # 📝 API客戶端 | 責任: HTTP請求封裝
│    │   │   ├── supabase.ts                    # 📝 Supabase客戶端 | 責任: 資料庫連接
│    │   │   ├── auth.ts                        # 📝 認證工具 | 責任: 令牌處理
│    │   │   ├── format.ts                      # 📝 格式化工具 | 責任: 日期、數字格式
│    │   │   ├── validation.ts                  # 📝 驗證工具 | 責任: 表單驗證邏輯
│    │   │   └── utils.ts                       # 📝 通用工具 | 責任: 雜項輔助函數
│    │   │
│    │   ├── 🏪 store/ - 狀態管理 (📝 待開發)
│    │   │   ├── auth.ts                        # 📝 認證Store | 責任: 使用者狀態
│    │   │   ├── contracts.ts                   # 📝 契約Store | 責任: 契約列表狀態
│    │   │   ├── ui.ts                          # 📝 UI Store | 責任: 側邊欄、主題
│    │   │   └── index.ts                       # 📝 Store匯出 | 責任: 統一匯出
│    │   │
│    │   ├── 🎨 styles/ - 樣式檔案 (🔧 可選)
│    │   │   ├── themes/
│    │   │   │   ├── light.css                  # 🔧 亮色主題 | 責任: 亮色變數
│    │   │   │   └── dark.css                   # 🔧 暗色主題 | 責任: 暗色變數
│    │   │   └── animations.css                 # 🔧 動畫樣式 | 責任: 自定義動畫
│    │   │
│    │   └── 📐 types/ - 型別定義 (📝 待開發)
│    │       ├── contract.ts                    # 📝 契約型別 | 責任: Contract相關型別
│    │       ├── user.ts                        # 📝 使用者型別 | 責任: User相關型別
│    │       ├── analysis.ts                    # 📝 分析型別 | 責任: Analysis相關型別
│    │       └── api.ts                         # 📝 API型別 | 責任: API請求/響應型別
│    │
│    ├── 🔬 tests/ - 測試檔案 (📝 待開發)
│    │   ├── unit/                              # 📝 單元測試 | 責任: 組件/函數測試
│    │   ├── integration/                       # 📝 整合測試 | 責任: 頁面流程測試
│    │   └── e2e/                               # 📝 E2E測試 | 責任: 完整用戶流程
│    │
│    └── 📂 public/ - 靜態資源 (📝 待補充)
│        ├── favicon.ico                        # 🔧 網站圖標 | 責任: 瀏覽器標籤圖示
│        ├── logo.svg                           # 📝 Logo | 責任: 品牌標識
│        ├── images/                            # 📝 圖片資源 | 責任: 靜態圖片
│        └── fonts/                             # 🔧 字體檔案 | 責任: 自訂字體
│
├─── ⚙️  後端API (apps/api/) - 🚧 開發中
│    │
│    ├── 📦 套件配置
│    │   ├── package.json                       # 🔒 後端依賴 | 責任: Express相關套件
│    │   ├── tsconfig.json                      # 🔒 後端TS | 責任: 伺服器端型別規則
│    │   └── nodemon.json                       # 🔧 熱重載配置 | 責任: 開發時自動重啟
│    │
│    ├── 📁 src/ - 源代碼目錄
│    │   │
│    │   ├── index.ts                           # ✅ 應用入口 | 責任: 伺服器啟動、中間件
│    │   ├── app.ts                             # 📝 Express應用 | 責任: 應用配置、路由註冊
│    │   ├── server.ts                          # 📝 伺服器邏輯 | 責任: HTTP伺服器創建
│    │   │
│    │   ├── 🛣️ routes/ - API路由定義 (📝 待開發)
│    │   │   ├── index.ts                       # 📝 路由匯總 | 責任: 所有路由註冊
│    │   │   ├── auth.routes.ts                 # 📝 認證路由 | 責任: 登入、註冊端點
│    │   │   ├── contracts.routes.ts            # 📝 契約路由 | 責任: 契約CRUD端點
│    │   │   ├── analysis.routes.ts             # 📝 分析路由 | 責任: AI分析端點
│    │   │   ├── search.routes.ts               # 📝 搜尋路由 | 責任: 語義搜尋端點
│    │   │   ├── users.routes.ts                # 📝 使用者路由 | 責任: 使用者管理端點
│    │   │   └── webhooks.routes.ts             # 📝 Webhook路由 | 責任: 第三方回調
│    │   │
│    │   ├── 🎮 controllers/ - 控制器層 (📝 待開發)
│    │   │   ├── auth.controller.ts             # 📝 認證控制器 | 責任: 認證業務協調
│    │   │   ├── contracts.controller.ts        # 📝 契約控制器 | 責任: 契約業務協調
│    │   │   ├── analysis.controller.ts         # 📝 分析控制器 | 責任: 分析業務協調
│    │   │   ├── search.controller.ts           # 📝 搜尋控制器 | 責任: 搜尋業務協調
│    │   │   └── users.controller.ts            # 📝 使用者控制器 | 責任: 使用者業務協調
│    │   │
│    │   ├── 💼 services/ - 業務邏輯層 (📝 待開發)
│    │   │   ├── auth.service.ts                # 📝 認證服務 | 責任: JWT、密碼處理
│    │   │   ├── contracts.service.ts           # 📝 契約服務 | 責任: 契約業務邏輯
│    │   │   ├── upload.service.ts              # 📝 上傳服務 | 責任: S3檔案處理
│    │   │   ├── parser.service.ts              # 📝 解析服務 | 責任: PDF/Word提取
│    │   │   ├── analysis.service.ts            # 📝 分析服務 | 責任: AI調用邏輯
│    │   │   ├── semantic.service.ts            # 📝 語義服務 | 責任: 向量化、圖查詢
│    │   │   ├── notification.service.ts        # 📝 通知服務 | 責任: 郵件、推送
│    │   │   └── user.service.ts                # 📝 使用者服務 | 責任: 使用者資料處理
│    │   │
│    │   ├── 🔒 middleware/ - 中間件 (📝 待開發)
│    │   │   ├── auth.middleware.ts             # 📝 認證中間件 | 責任: JWT驗證
│    │   │   ├── validation.middleware.ts       # 📝 驗證中間件 | 責任: 請求驗證
│    │   │   ├── rate-limit.middleware.ts       # 📝 限流中間件 | 責任: API速率限制
│    │   │   ├── error.middleware.ts            # 📝 錯誤中間件 | 責任: 全域錯誤處理
│    │   │   ├── logging.middleware.ts          # 📝 日誌中間件 | 責任: 請求日誌
│    │   │   └── cors.middleware.ts             # 📝 CORS中間件 | 責任: 跨域處理
│    │   │
│    │   ├── 📐 models/ - 資料模型 (🔧 可選,已用Prisma)
│    │   │   └── README.md                      # ✅ 說明 | 責任: 解釋使用Prisma
│    │   │
│    │   ├── 📋 validators/ - 驗證器 (📝 待開發)
│    │   │   ├── auth.validator.ts              # 📝 認證驗證 | 責任: 登入註冊驗證
│    │   │   ├── contract.validator.ts          # 📝 契約驗證 | 責任: 契約資料驗證
│    │   │   └── user.validator.ts              # 📝 使用者驗證 | 責任: 使用者資料驗證
│    │   │
│    │   ├── 🛠️ utils/ - 工具函數 (📝 待開發)
│    │   │   ├── logger.ts                      # 📝 日誌工具 | 責任: Winston日誌封裝
│    │   │   ├── crypto.ts                      # 📝 加密工具 | 責任: 加解密、雜湊
│    │   │   ├── jwt.ts                         # 📝 JWT工具 | 責任: 令牌生成驗證
│    │   │   ├── file.ts                        # 📝 檔案工具 | 責任: 檔案處理輔助
│    │   │   └── format.ts                      # 📝 格式化工具 | 責任: 資料格式轉換
│    │   │
│    │   ├── 🔧 config/ - 配置管理 (📝 待開發)
│    │   │   ├── index.ts                       # 📝 配置匯出 | 責任: 統一配置入口
│    │   │   ├── database.ts                    # 📝 資料庫配置 | 責任: Prisma連接
│    │   │   ├── redis.ts                       # 📝 Redis配置 | 責任: Redis連接
│    │   │   ├── s3.ts                          # 📝 S3配置 | 責任: 物件儲存
│    │   │   ├── openai.ts                      # 📝 OpenAI配置 | 責任: AI服務連接
│    │   │   └── email.ts                       # 📝 郵件配置 | 責任: 郵件服務
│    │   │
│    │   └── 📐 types/ - 型別定義 (📝 待開發)
│    │       ├── express.d.ts                   # 📝 Express擴展 | 責任: 擴展Express型別
│    │       ├── custom.d.ts                    # 📝 自定義型別 | 責任: 專案特定型別
│    │       └── index.ts                       # 📝 型別匯出 | 責任: 統一型別匯出
│    │
│    └── 🔬 tests/ - 測試檔案 (📝 待開發)
│        ├── unit/                              # 📝 單元測試 | 責任: 服務/工具測試
│        ├── integration/                       # 📝 整合測試 | 責任: API端點測試
│        └── fixtures/                          # 📝 測試數據 | 責任: Mock數據
│
├─── 🔄 背景任務處理器 (apps/worker/) - 📝 待開發
│    │
│    ├── 📦 套件配置
│    │   ├── package.json                       # 📝 Worker依賴 | 責任: Bull、處理器套件
│    │   └── tsconfig.json                      # 📝 Worker TS | 責任: 型別規則
│    │
│    └── 📁 src/
│        ├── index.ts                           # 📝 Worker入口 | 責任: 佇列初始化
│        ├── queue.ts                           # 📝 佇列配置 | 責任: Bull Queue設定
│        │
│        ├── 📋 jobs/ - 任務定義 (📝 待開發)
│        │   ├── analysis.job.ts                # 📝 分析任務 | 責任: AI分析邏輯
│        │   ├── parsing.job.ts                 # 📝 解析任務 | 責任: 文件解析
│        │   ├── indexing.job.ts                # 📝 索引任務 | 責任: 語義索引
│        │   ├── notification.job.ts            # 📝 通知任務 | 責任: 郵件發送
│        │   └── cleanup.job.ts                 # 📝 清理任務 | 責任: 過期資料清理
│        │
│        └── 🔧 processors/ - 任務處理器 (📝 待開發)
│            ├── analysis.processor.ts          # 📝 分析處理器 | 責任: 執行AI分析
│            ├── parsing.processor.ts           # 📝 解析處理器 | 責任: 執行文件解析
│            └── indexing.processor.ts          # 📝 索引處理器 | 責任: 執行索引更新
│
├─── 📦 共享套件 (packages/)
│    │
│    ├── 🔤 shared - 共享型別與工具 (📝 待開發)
│    │   ├── package.json                       # 📝 共享依賴 | 責任: 通用套件
│    │   ├── tsconfig.json                      # 📝 共享TS | 責任: 型別規則
│    │   └── src/
│    │       ├── index.ts                       # 📝 統一匯出 | 責任: 公開API
│    │       │
│    │       ├── 📐 types/ - 型別定義
│    │       │   ├── contract.ts                # 📝 契約型別 | 責任: Contract介面
│    │       │   ├── user.ts                    # 📝 使用者型別 | 責任: User介面
│    │       │   ├── analysis.ts                # 📝 分析型別 | 責任: Analysis介面
│    │       │   ├── api.ts                     # 📝 API型別 | 責任: 請求響應介面
│    │       │   └── common.ts                  # 📝 通用型別 | 責任: 基礎型別定義
│    │       │
│    │       ├── 🔢 constants/ - 常量定義
│    │       │   ├── status.ts                  # 📝 狀態常量 | 責任: 枚舉狀態值
│    │       │   ├── errors.ts                  # 📝 錯誤常量 | 責任: 錯誤代碼定義
│    │       │   ├── routes.ts                  # 📝 路由常量 | 責任: API路徑定義
│    │       │   └── config.ts                  # 📝 配置常量 | 責任: 共享配置值
│    │       │
│    │       ├── 🛠️ utils/ - 工具函數
│    │       │   ├── format.ts                  # 📝 格式化 | 責任: 通用格式化
│    │       │   ├── validation.ts              # 📝 驗證 | 責任: 通用驗證邏輯
│    │       │   └── helpers.ts                 # 📝 輔助函數 | 責任: 雜項工具
│    │       │
│    │       └── 📋 validators/ - Zod驗證器
│    │           ├── auth.schema.ts             # 📝 認證Schema | 責任: 認證驗證
│    │           ├── contract.schema.ts         # 📝 契約Schema | 責任: 契約驗證
│    │           └── user.schema.ts             # 📝 使用者Schema | 責任: 使用者驗證
│    │
│    ├── 🎨 ui - UI組件庫 (📝 待開發)
│    │   ├── package.json                       # 📝 UI依賴 | 責任: React、Radix套件
│    │   ├── tsconfig.json                      # 📝 UI TS | 責任: React型別規則
│    │   └── src/
│    │       ├── index.ts                       # 📝 組件匯出 | 責任: 公開所有組件
│    │       │
│    │       ├── 🧩 components/ - UI組件
│    │       │   ├── button.tsx                 # 📝 按鈕組件 | 責任: 可重用按鈕
│    │       │   ├── input.tsx                  # 📝 輸入框 | 責任: 表單輸入
│    │       │   ├── card.tsx                   # 📝 卡片 | 責任: 內容容器
│    │       │   └── [其他組件...]
│    │       │
│    │       ├── 🎣 hooks/ - 共享Hooks
│    │       │   └── use-theme.ts               # 📝 主題Hook | 責任: 主題切換
│    │       │
│    │       └── 🎨 styles/ - 共享樣式
│    │           └── tokens.ts                  # 📝 設計令牌 | 責任: 顏色、間距
│    │
│    ├── 🤖 ai-engine - AI推理引擎 (📝 待開發)
│    │   ├── package.json                       # 📝 AI依賴 | 責任: OpenAI、LangChain
│    │   ├── tsconfig.json                      # 📝 AI TS | 責任: 型別規則
│    │   └── src/
│    │       ├── index.ts                       # 📝 引擎匯出 | 責任: 公開API
│    │       │
│    │       ├── 🔌 providers/ - AI提供商
│    │       │   ├── openai.ts                  # 📝 OpenAI | 責任: GPT調用
│    │       │   ├── anthropic.ts               # 📝 Anthropic | 責任: Claude調用
│    │       │   ├── google.ts                  # 📝 Google | 責任: Gemini調用
│    │       │   └── huggingface.ts             # 📝 HuggingFace | 責任: 開源模型
│    │       │
│    │       ├── 🎯 router/ - 智能路由
│    │       │   ├── index.ts                   # 📝 路由器 | 責任: 模型選擇邏輯
│    │       │   ├── cost-tracker.ts            # 📝 成本追蹤 | 責任: 使用量計費
│    │       │   └── load-balancer.ts           # 📝 負載均衡 | 責任: 請求分配
│    │       │
│    │       ├── 💾 cache/ - 結果快取
│    │       │   └── index.ts                   # 📝 快取管理 | 責任: Redis快取
│    │       │
│    │       └── 📋 prompts/ - 提示範本
│    │           ├── analysis.ts                # 📝 分析提示 | 責任: 契約分析Prompt
│    │           └── classification.ts          # 📝 分類提示 | 責任: 條款分類Prompt
│    │
│    ├── 🔍 semantic-engine - 語義引擎 (📝 待開發)
│    │   ├── package.json                       # 📝 語義依賴 | 責任: 向量、圖資料庫
│    │   ├── tsconfig.json                      # 📝 語義TS | 責任: 型別規則
│    │   └── src/
│    │       ├── index.ts                       # 📝 引擎匯出 | 責任: 公開API
│    │       │
│    │       ├── 📊 vector/ - 向量化引擎
│    │       │   ├── embeddings.ts              # 📝 向量化 | 責任: 文本轉向量
│    │       │   ├── pinecone.ts                # 📝 Pinecone客戶端 | 責任: 向量儲存
│    │       │   ├── qdrant.ts                  # 📝 Qdrant客戶端 | 責任: 向量儲存
│    │       │   └── search.ts                  # 📝 向量搜尋 | 責任: 相似度查詢
│    │       │
│    │       ├── 🕸️ graph/ - 圖結構引擎
│    │       │   ├── neo4j.ts                   # 📝 Neo4j客戶端 | 責任: 圖資料庫
│    │       │   ├── queries.ts                 # 📝 圖查詢 | 責任: Cypher查詢
│    │       │   └── traversal.ts               # 📝 圖遍歷 | 責任: 路徑查找
│    │       │
│    │       ├── 🔀 hybrid/ - 混合搜尋
│    │       │   ├── fusion.ts                  # 📝 結果融合 | 責任: 多源結果合併
│    │       │   └── ranking.ts                 # 📝 排序算法 | 責任: 相關性排序
│    │       │
│    │       └── 📈 indexing/ - 實時索引
│    │           ├── chunking.ts                # 📝 文本分塊 | 責任: 語義切分
│    │           └── update.ts                  # 📝 索引更新 | 責任: 增量索引
│    │
│    └── 💾 database - 資料庫套件 (✅ 已完成)
│        ├── package.json                       # ✅ 資料庫依賴 | 責任: Prisma套件
│        └── prisma/
│            ├── schema.prisma                  # ✅ Schema定義 | 責任: 資料模型
│            ├── seed.ts                        # ✅ 種子數據 | 責任: 測試數據
│            └── migrations/                    # ⚙️  遷移歷史 | 責任: 版本演進
│
├─── 🐳 Docker配置 (docker/)
│    ├── docker-compose.dev.yml                 # ✅ 開發環境 | 責任: 本地服務編排
│    ├── docker-compose.prod.yml                # 📝 生產環境 | 責任: 生產服務編排
│    ├── Dockerfile.web                         # 📝 前端映像 | 責任: Next.js容器化
│    ├── Dockerfile.api                         # 📝 後端映像 | 責任: Express容器化
│    ├── Dockerfile.worker                      # 📝 Worker映像 | 責任: Bull容器化
│    └── .dockerignore                          # 📝 Docker忽略 | 責任: 排除不需要文件
│
├─── 🤖 CI/CD配置 (.github/workflows/)
│    ├── pr-check.yml                           # ✅ PR檢查 | 責任: 代碼品質、測試
│    ├── deploy-dev.yml                         # 📝 開發部署 | 責任: 自動部署到dev
│    ├── deploy-staging.yml                     # 📝 測試部署 | 責任: 自動部署到staging
│    ├── deploy-production.yml                  # 📝 生產部署 | 責任: 審批後部署到prod
│    ├── security-scan.yml                      # 📝 安全掃描 | 責任: 漏洞檢測
│    └── performance-test.yml                   # 📝 性能測試 | 責任: 負載測試
│
├─── 📜 自動化腳本 (scripts/)
│    │
│    ├── 🛠️ setup/ - 環境設定
│    │   ├── setup-dev.sh                       # ✅ 開發設定 | 責任: 一鍵環境初始化
│    │   ├── setup-ci.sh                        # 📝 CI設定 | 責任: CI環境準備
│    │   └── install-deps.sh                    # 📝 依賴安裝 | 責任: 跨平台依賴安裝
│    │
│    ├── 💾 database/ - 資料庫管理
│    │   ├── backup.sh                          # 📝 備份腳本 | 責任: 自動備份資料庫
│    │   ├── restore.sh                         # 📝 恢復腳本 | 責任: 從備份恢復
│    │   ├── migrate.sh                         # 📝 遷移腳本 | 責任: 執行遷移
│    │   └── init.sql                           # 📝 初始化SQL | 責任: 初始資料庫設定
│    │
│    ├── 🚀 deployment/ - 部署腳本
│    │   ├── deploy-vercel.sh                   # 📝 Vercel部署 | 責任: 前端部署
│    │   ├── deploy-railway.sh                  # 📝 Railway部署 | 責任: 後端部署
│    │   ├── rollback.sh                        # 📝 回滾腳本 | 責任: 版本回滾
│    │   └── health-check.sh                    # 📝 健康檢查 | 責任: 部署後驗證
│    │
│    ├── 📊 monitoring/ - 監控相關
│    │   ├── cost-report.sh                     # 📝 成本報告 | 責任: 生成成本報表
│    │   └── metrics-export.sh                  # 📝 指標匯出 | 責任: 匯出監控數據
│    │
│    └── 🔧 utils/ - 工具腳本
│        ├── generate-types.sh                  # 📝 型別生成 | 責任: 從Schema生成型別
│        ├── seed-data.sh                       # 📝 數據播種 | 責任: 載入測試數據
│        └── clean.sh                           # 📝 清理腳本 | 責任: 清理構建產物
│
├─── ⚙️  配置文件 (config/)
│    ├── architecture-evolution.yml             # ✅ 架構演進 | 責任: 演進策略定義
│    ├── semantic-engine.yml                    # ✅ 語義引擎 | 責任: 引擎參數配置
│    ├── ai-models.yml                          # 📝 AI模型配置 | 責任: 模型選擇策略
│    │
│    ├── 💼 business-rules/ - 業務規則
│    │   ├── risk-scoring.yml                   # 📝 風險評分 | 責任: 評分規則定義
│    │   ├── compliance-checks.yml              # 📝 合規檢查 | 責任: 檢查清單
│    │   └── pricing-tiers.yml                  # 📝 定價方案 | 責任: 訂閱計畫配置
│    │
│    ├── 🚀 deployment/ - 部署配置
│    │   ├── dev.yml                            # 📝 開發環境 | 責任: Dev配置參數
│    │   ├── staging.yml                        # 📝 測試環境 | 責任: Staging配置
│    │   └── production.yml                     # 📝 生產環境 | 責任: Prod配置
│    │
│    └── 📊 monitoring/ - 監控配置
│        ├── alerts.yml                         # 📝 告警規則 | 責任: 告警閾值定義
│        └── dashboards.yml                     # 📝 儀表板配置 | 責任: Grafana配置
│
├─── 📚 文檔系統 (docs/)
│    │
│    ├── 🏗️ architecture/ - 架構文檔
│    │   ├── system-design.md                   # 📝 系統設計 | 責任: 整體架構說明
│    │   ├── data-model.md                      # 📝 資料模型 | 責任: 資料庫設計文檔
│    │   ├── evolution-guide.md                 # ✅ 演進指南 | 責任: 架構演進策略
│    │   ├── security.md                        # 📝 安全架構 | 責任: 安全設計文檔
│    │   └── ADR/                               # 📝 決策記錄 | 責任: 架構決策歷史
│    │       ├── 001-monorepo-structure.md
│    │       ├── 002-database-choice.md
│    │       └── 003-ai-provider-strategy.md
│    │
│    ├── 🔌 api/ - API文檔
│    │   ├── openapi.yml                        # 📝 OpenAPI規範 | 責任: REST API定義
│    │   ├── graphql-schema.gql                 # 📝 GraphQL Schema | 責任: GraphQL定義
│    │   ├── webhooks.md                        # 📝 Webhook文檔 | 責任: 回調說明
│    │   └── authentication.md                  # 📝 認證文檔 | 責任: 認證流程說明
│    │
│    ├── 💻 development/ - 開發指南
│    │   ├── setup.md                           # 📝 環境設定 | 責任: 詳細設定步驟
│    │   ├── contributing.md                    # 📝 貢獻指南 | 責任: 協作規範
│    │   ├── coding-standards.md                # 📝 編碼規範 | 責任: 代碼風格指南
│    │   ├── testing.md                         # 📝 測試指南 | 責任: 測試策略說明
│    │   ├── debugging.md                       # 📝 調試指南 | 責任: 常見問題排查
│    │   └── troubleshooting.md                 # 📝 故障排除 | 責任: 問題解決方案
│    │
│    ├── 🚀 deployment/ - 部署文檔
│    │   ├── zero-cost-deployment-guide.md      # ✅ 零成本部署 | 責任: 免費部署指南
│    │   ├── production-checklist.md            # 📝 上線檢查 | 責任: 生產環境清單
│    │   ├── scaling-guide.md                   # 📝 擴展指南 | 責任: 水平擴展策略
│    │   ├── migration-guide.md                 # 📝 遷移指南 | 責任: 數據遷移步驟
│    │   └── disaster-recovery.md               # 📝 災難恢復 | 責任: 備份恢復計畫
│    │
│    └── 👥 user-guides/ - 使用者指南
│        ├── getting-started.md                 # 📝 快速入門 | 責任: 新使用者導覽
│        ├── features.md                        # 📝 功能說明 | 責任: 完整功能介紹
│        ├── faq.md                             # 📝 常見問題 | 責任: FAQ彙整
│        └── api-usage.md                       # 📝 API使用 | 責任: API使用範例
│
├─── 🧪 測試套件 (tests/)
│    ├── e2e/                                   # 📝 E2E測試 | 責任: 端到端測試
│    │   ├── playwright.config.ts               # 📝 Playwright配置 | 責任: E2E測試設定
│    │   └── specs/
│    │       ├── auth.spec.ts                   # 📝 認證測試 | 責任: 登入註冊流程
│    │       ├── contract-upload.spec.ts        # 📝 上傳測試 | 責任: 契約上傳流程
│    │       └── analysis.spec.ts               # 📝 分析測試 | 責任: AI分析流程
│    │
│    ├── integration/                           # 📝 整合測試 | 責任: API整合測試
│    │   └── api/
│    │       ├── auth.test.ts                   # 📝 認證API | 責任: 認證端點測試
│    │       └── contracts.test.ts              # 📝 契約API | 責任: 契約端點測試
│    │
│    ├── load/                                  # 📝 負載測試 | 責任: 性能壓力測試
│    │   ├── k6.config.js                       # 📝 K6配置 | 責任: 負載測試設定
│    │   └── scenarios/
│    │       └── basic-flow.js                  # 📝 基本流程 | 責任: 常用場景測試
│    │
│    └── fixtures/                              # 📝 測試數據 | 責任: Mock數據、範例文件
│        ├── contracts/
│        │   ├── sample-nda.pdf
│        │   └── sample-employment.pdf
│        └── users/
│            └── test-users.json
│
├─── 🏗️ 基礎設施即代碼 (infra/)
│    ├── terraform/                             # 📝 Terraform | 責任: AWS資源定義
│    │   ├── main.tf
│    │   ├── variables.tf
│    │   └── outputs.tf
│    │
│    └── kubernetes/                            # 📝 Kubernetes | 責任: K8s資源定義
│        ├── manifests/
│        │   ├── deployment.yml
│        │   ├── service.yml
│        │   └── ingress.yml
│        ├── helm-charts/
│        └── kustomize/
│
└─── 📊 監控與日誌 (monitoring/)
     ├── prometheus/                            # 📝 Prometheus | 責任: 指標收集配置
     │   └── prometheus.yml
     ├── grafana/                               # 📝 Grafana | 責任: 儀表板定義
     │   └── dashboards/
     │       ├── system-health.json
     │       └── api-performance.json
     └── loki/                                  # 📝 Loki | 責任: 日誌聚合配置
         └── loki-config.yml
```

---

## 📋 責任邊界規範

### 1. 目錄層級責任劃分

#### 根目錄層 (Root Level)
**責任**: 專案整體配置與協作規範
- ✅ 套件管理 (package.json, pnpm-workspace.yaml)
- ✅ 構建配置 (turbo.json, tsconfig.json)
- ✅ 代碼規範 (.eslintrc.js, .prettierrc)
- ✅ 版本控制 (.gitignore)
- ✅ 法律文件 (LICENSE)
- ✅ 協作文檔 (README.md, CONTRIBUTING.md)

**禁止**: 
- ❌ 不應包含業務邏輯代碼
- ❌ 不應包含特定應用的配置
- ❌ 不應包含敏感資訊

#### 應用層 (apps/*)
**責任**: 獨立可部署的應用程序
- ✅ 應用入口點
- ✅ 路由定義
- ✅ 應用特定配置
- ✅ 應用特定依賴

**禁止**:
- ❌ 不應直接存取其他應用的內部模組
- ❌ 不應包含可共享的業務邏輯
- ❌ 不應重複實作已在packages中的功能

#### 套件層 (packages/*)
**責任**: 可重用的共享程式碼
- ✅ 型別定義
- ✅ 工具函數
- ✅ UI組件庫
- ✅ 業務邏輯引擎

**禁止**:
- ❌ 不應依賴特定應用
- ❌ 不應包含應用特定邏輯
- ❌ 不應有副作用(純函數優先)

#### 配置層 (config/*)
**責任**: 零碼配置文件
- ✅ 業務規則定義
- ✅ 環境配置參數
- ✅ 監控告警規則

**禁止**:
- ❌ 不應包含程式碼
- ❌ 不應包含敏感資訊(使用環境變數)
- ❌ 不應過度複雜(保持可讀性)

### 2. 文件責任邊界

#### 配置文件 (Configuration Files)
**單一責任**: 一個文件只負責一個配置面向

✅ **正確範例**:
```
tsconfig.json        → 只負責 TypeScript 編譯配置
.eslintrc.js         → 只負責代碼檢查規則
tailwind.config.js   → 只負責樣式系統配置
```

❌ **錯誤範例**:
```
config.js  → 混合了所有配置(違反單一責任)
```

#### 源代碼文件 (Source Code Files)
**單一責任**: 一個文件只負責一個業務概念

✅ **正確範例**:
```typescript
// auth.service.ts - 只負責認證業務邏輯
export class AuthService {
  login() { }
  register() { }
  verifyToken() { }
}

// email.service.ts - 只負責郵件發送
export class EmailService {
  sendVerification() { }
  sendPasswordReset() { }
}
```

❌ **錯誤範例**:
```typescript
// user.service.ts - 責任過多
export class UserService {
  login() { }           // 應該在 AuthService
  sendEmail() { }       // 應該在 EmailService
  uploadFile() { }      // 應該在 FileService
  analyzeContract() { } // 應該在 AnalysisService
}
```

### 3. 模組邊界規範

#### 層級依賴規則

```
上層可依賴下層，下層不可依賴上層

apps/web (前端)
  ↓ 可依賴
packages/shared (共享)
packages/ui (UI組件)
  ↓ 可依賴
packages/database (資料庫)
  ↓ 可依賴
Prisma Client (生成)

❌ 禁止: packages/shared 依賴 apps/web
❌ 禁止: packages/database 依賴 packages/ui
```

#### 水平隔離規則

```
同層模組互不依賴

apps/web  ←✗→  apps/api  ←✗→  apps/worker
只能透過 API 或消息佇列通訊

packages/ai-engine  ←✗→  packages/semantic-engine
只能透過明確定義的介面通訊
```

---

## 🏷️ 命名規範

### 1. 目錄命名 (Directory Naming)

#### 規則
- **小寫+連字符**: `kebab-case`
- **複數形式**: 內容為多個項目時使用複數
- **簡潔清晰**: 見名知義

#### 範例
```
✅ 正確:
components/        # 複數 - 包含多個組件
contracts/         # 複數 - 契約相關文件
auth/              # 單數 - 認證功能模組
user-settings/     # 連字符分隔

❌ 錯誤:
Components/        # 大寫開頭
contract/          # 應該用複數
authModule/        # 駝峰命名
user_settings/     # 底線分隔
```

### 2. 文件命名 (File Naming)

#### TypeScript/JavaScript 文件
```
功能文件: kebab-case.ts
  ✅ auth.service.ts
  ✅ contract-parser.ts
  ✅ user-settings.controller.ts

React 組件: PascalCase.tsx
  ✅ Button.tsx
  ✅ ContractCard.tsx
  ✅ UserProfile.tsx

測試文件: 原名.test.ts 或 原名.spec.ts
  ✅ auth.service.test.ts
  ✅ Button.spec.tsx
```

#### 配置文件
```
✅ 正確:
package.json           # 標準命名
tsconfig.json          # 標準命名
.env.example           # 點開頭表隱藏
docker-compose.yml     # 連字符分隔

❌ 錯誤:
Package.json           # 大寫
tsConfig.json          # 駝峰
env.example            # 缺少點前綴
dockerCompose.yml      # 駝峰
```

### 3. 變數與函數命名

#### 變數命名 (camelCase)
```typescript
✅ 正確:
const userId = '123';
const contractList = [];
const isAuthenticated = true;
const maxRetryCount = 3;

❌ 錯誤:
const user_id = '123';        // 底線
const ContractList = [];      // 大寫開頭
const is_authenticated = true;// 底線
```

#### 函數命名 (camelCase + 動詞開頭)
```typescript
✅ 正確:
function getUserById(id: string) { }
function validateContract(data: Contract) { }
function calculateRiskScore() { }
async function fetchAnalysisResult() { }

❌ 錯誤:
function user(id: string) { }        // 缺少動詞
function ContractValidator() { }     // 大寫開頭
function risk_score() { }            // 底線
```

#### 常量命名 (UPPER_SNAKE_CASE)
```typescript
✅ 正確:
const MAX_FILE_SIZE = 50 * 1024 * 1024;
const API_BASE_URL = 'https://api.example.com';
const DEFAULT_PAGE_SIZE = 20;

❌ 錯誤:
const maxFileSize = 50 * 1024 * 1024;  // 應該全大寫
const apiBaseUrl = 'https://...';      // 應該全大寫
```

#### 類型與介面命名 (PascalCase)
```typescript
✅ 正確:
interface User { }
interface ContractAnalysis { }
type RiskLevel = 'low' | 'medium' | 'high';
enum SubscriptionPlan { }

❌ 錯誤:
interface user { }          // 小寫開頭
type riskLevel = ...;       // 小寫開頭
enum subscription_plan { }  // 底線
```

### 4. 鍵名規範 (Object Keys)

#### API 請求/響應 (snake_case)
```typescript
✅ 正確 - API 層:
{
  "user_id": "123",
  "contract_id": "456",
  "created_at": "2024-02-08",
  "risk_level": "medium"
}

✅ 正確 - 應用層:
interface User {
  userId: string;        // camelCase for TypeScript
  contractId: string;
  createdAt: Date;
  riskLevel: RiskLevel;
}

// 使用轉換函數
function toAPI(user: User): APIUser {
  return {
    user_id: user.userId,
    contract_id: user.contractId,
    // ...
  };
}
```

#### 資料庫欄位 (snake_case)
```prisma
✅ 正確:
model User {
  id         String   @id
  email      String   @unique
  created_at DateTime @default(now())
  updated_at DateTime @updatedAt
  
  @@map("users")  // 表名也是 snake_case
}
```

#### 配置文件鍵名 (kebab-case 或 snake_case)
```yaml
✅ 正確 (YAML):
semantic-engine:
  vector-folding:
    enabled: true
    model-name: "sentence-transformers"
  graph-folding:
    enabled: true

✅ 正確 (環境變數):
DATABASE_URL=...
OPENAI_API_KEY=...
NEXT_PUBLIC_API_URL=...
```

### 5. 值名規範 (Value Naming)

#### 枚舉值 (UPPER_SNAKE_CASE)
```typescript
✅ 正確:
enum ContractStatus {
  UPLOADING = 'UPLOADING',
  PROCESSING = 'PROCESSING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED'
}

enum SubscriptionPlan {
  FREE = 'FREE',
  STARTER = 'STARTER',
  PROFESSIONAL = 'PROFESSIONAL',
  ENTERPRISE = 'ENTERPRISE'
}
```

#### 字串常量 (kebab-case)
```typescript
✅ 正確:
const routes = {
  home: '/',
  login: '/auth/login',
  dashboard: '/dashboard',
  contractDetail: '/dashboard/contracts/:id',  // 變數用 camelCase
  // URL 本身用 kebab-case
};

const errorCodes = {
  notFound: 'not-found',
  unauthorized: 'unauthorized',
  invalidInput: 'invalid-input'
};
```

---

## 🔒 強制機構清單

以下文件**必須嚴格遵守規範**,任何變更需經過審查:

### 專案根層
```
🔒 package.json           # 依賴版本鎖定
🔒 pnpm-workspace.yaml    # 工作區結構固定
🔒 turbo.json             # 任務依賴關係
🔒 tsconfig.json          # 全域型別規則
🔒 .gitignore             # 版本控制規則
🔒 .eslintrc.js           # 代碼品質標準
🔒 .prettierrc            # 格式化規則
```

### 資料庫層
```
🔒 packages/database/prisma/schema.prisma  # 資料模型定義
🔒 packages/database/prisma/migrations/*   # 遷移歷史(不可修改)
```

### API 契約
```
🔒 docs/api/openapi.yml          # API 規範
🔒 packages/shared/src/types/*   # 共享型別定義
```

### 配置層
```
🔒 config/architecture-evolution.yml  # 架構策略
🔒 .env.example                      # 環境變數文檔
```

---

## ⚙️ 工作機構清單

以下是**運行時動態生成**的文件,不應提交到版本控制:

### 構建產物
```
⚙️  apps/web/.next/*           # Next.js 構建輸出
⚙️  apps/api/dist/*            # TypeScript 編譯輸出
⚙️  packages/*/dist/*          # 套件構建輸出
```

### 依賴與快取
```
⚙️  node_modules/*             # npm 套件
⚙️  .turbo/*                   # Turbo 快取
⚙️  .next/cache/*              # Next.js 快取
```

### 環境配置
```
⚙️  .env.local                 # 本地環境變數
⚙️  .env.production            # 生產環境變數
```

### 日誌與臨時文件
```
⚙️  logs/*                     # 應用日誌
⚙️  *.log                      # 各種日誌文件
⚙️  tmp/*                      # 臨時文件
```

### 資料庫生成
```
⚙️  packages/database/prisma/migrations/migration_lock.toml
⚙️  node_modules/.prisma/*     # Prisma 客戶端
```

---

## 📊 元數據規範

### 文件頭部註釋規範

#### TypeScript/JavaScript 文件
```typescript
/**
 * @file auth.service.ts
 * @description 使用者認證服務 - 處理登入、註冊、令牌驗證
 * @module services/auth
 * @author Contracts-L1 Team
 * @created 2024-02-08
 * @responsibility 認證業務邏輯、JWT處理、密碼雜湊
 */
```

#### React 組件
```typescript
/**
 * @component Button
 * @description 可重用按鈕組件 - 支援多種變體與狀態
 * @module components/ui
 * @responsibility UI渲染、事件處理、樣式變體
 * 
 * @example
 * <Button variant="primary" onClick={handleClick}>
 *   Click Me
 * </Button>
 */
```

#### 配置文件
```yaml
# ============================================================================
# 語義引擎配置
# 
# 文件: semantic-engine.yml
# 責任: 定義語義搜尋引擎的所有參數
# 修改: 需經過技術評審
# 影響: 搜尋準確度、性能、成本
# ============================================================================
```

### package.json 元數據規範
```json
{
  "name": "@contracts-l1/api",
  "version": "1.0.0",
  "description": "Contracts-L1 後端 API 服務",
  "author": "Contracts-L1 Team",
  "license": "MIT",
  "repository": {
    "type": "git",
    "url": "https://github.com/your-org/contracts-l1",
    "directory": "apps/api"
  },
  "keywords": [
    "contracts",
    "ai",
    "analysis",
    "api"
  ],
  "main": "dist/index.js",
  "types": "dist/index.d.ts"
}
```

### Prisma Schema 元數據
```prisma
/// 使用者資料表
/// 責任: 儲存使用者基本資訊、認證資料、訂閱狀態
/// 關聯: RefreshToken, Contract, ApiKey
model User {
  id        String   @id @default(cuid())
  
  /// 電子郵件地址 - 唯一識別符
  email     String   @unique
  
  /// 密碼雜湊值 - bcrypt加密,OAuth用戶為null
  password  String?
  
  @@map("users")
  @@index([email])
}
```

---

## ✅ 檢查清單

### 新增文件檢查清單
- [ ] 文件命名符合規範?
- [ ] 目錄位置正確?
- [ ] 責任邊界清晰?
- [ ] 依賴關係合理?
- [ ] 包含文件頭部註釋?
- [ ] 型別定義完整?
- [ ] 測試文件對應?
- [ ] 文檔已更新?

### 修改文件檢查清單
- [ ] 變更是否越界?
- [ ] 影響範圍評估?
- [ ] 向後兼容性?
- [ ] 測試是否通過?
- [ ] 文檔是否同步?
- [ ] 遷移腳本是否需要?

### 重構檢查清單
- [ ] 單一責任是否保持?
- [ ] 模組邊界是否清晰?
- [ ] 命名是否一致?
- [ ] 重複代碼是否消除?
- [ ] 測試覆蓋是否完整?

---

這份目錄樹總圖表確保了專案的**單一責任**、**清晰邊界**、**不越界**原則,為大型專案的長期維護提供堅實基礎。
